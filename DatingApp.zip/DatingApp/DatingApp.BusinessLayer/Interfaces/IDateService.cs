﻿using System;
using System.Threading.Tasks;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Interfaces
{
    public interface IDateService
    {
        Task<DateDetail> GetDateDetailById(long dateId);
        Task<DateDetail> GetDateDetailByUser(string RequestSenderName);
        Task<DateDetail> GetDateDetailByDate(DateTime DateOfRequest);
        Task<DateDetail> AddDateDetail(DateDetail appointment);
        Task<DateDetail> UpdateDateDetail(DateDetail appointment);
        Task<DateDetail> CancelDateDetail(DateDetail appointment);
        Task<String> SendRequest(DateDetail user);
    }
}
