﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.BusinessLayer.Interfaces;
using DatingApp.BusinessLayer.Services.Repository;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services
{
    public class UserService : IUserService
    {
        /// <summary>
        /// Creating instance/field of IUserRepository and injecting into UserService Constructor
        /// </summary>
        private readonly IUserRepository _userRepository;
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        /// <summary>
        /// Method used to Create\Add a new Profile
        /// </summary>
        /// <param name="profile"></param>
        /// <returns></returns>
        public async Task<bool> AddProfile(Profile profile)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method used to Change or rename their Profile Password
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="NewPassword"></param>
        /// <returns></returns>
        public async Task<string> ChangePassword(string UserName, string NewPassword)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///Method used to Create\Add a new User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<bool> CreateNewUser(User user)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///Method used to Display the list of Users available in the Application
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<User>> ListOfMembers()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///Method used to Suspend the existing Users 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="userStatus"></param>
        /// <returns></returns>
        public async Task<string> SuspendUser(string UserName, UserStatus userStatus)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///Method used to varify the existing Users 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public async Task<User> VerifyUser(string UserName, string Password)
        {
            throw new NotImplementedException();
        }
    }
}
