﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.DataLayer;
using DatingApp.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public class DateRepository : IDateRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in DateRepository constructor
        /// </summary>
        private readonly DatingAppDbContext _datingContext;
        public DateRepository(DatingAppDbContext datingDbContext)
        {
            _datingContext = datingDbContext;
        }

        /// <summary>
        /// Able to add a new date datails for an appointment
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<bool> AddDateDetail(DateDetail appointment)
        {
            try
            {
                await _datingContext.DateDetails.AddAsync(appointment);
                await _datingContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Able to cancel a existing date appointment
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<DateDetail> CancelDateDetail(DateDetail appointment)
        {
            try
            {
                _datingContext.DateDetails.Remove(appointment);
                await _datingContext.SaveChangesAsync();
                return await Task.FromResult(appointment);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Method used to get the date information by the date
        /// </summary>
        /// <param name="DateOfRequest"></param>
        /// <returns></returns>
        public async Task<DateDetail> GetDateDetailByDate(DateTime DateOfRequest)
        {
            try
            {
                var result = await _datingContext.DateDetails
                    .FirstOrDefaultAsync(h => h.DateOfRequest.Equals(DateOfRequest));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Method used to get the date information by the Dateid
        /// </summary>
        /// <param name="dateId"></param>
        /// <returns></returns>
        public async Task<DateDetail> GetDateDetailById(long dateId)
        {
            try
            {
                var result = await _datingContext.DateDetails
                    .FirstOrDefaultAsync(h => h.DateId.Equals(dateId));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Method used to get the date information by the User
        /// </summary>
        /// <param name="RequestSenderName"></param>
        /// <returns></returns>
        public async Task<DateDetail> GetDateDetailByUser(string RequestSenderName)
        {
            try
            {
                var result = await _datingContext.DateDetails
                    .FirstOrDefaultAsync(h => h.RequestSenderName.Equals(RequestSenderName));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Method used to send the new date Request
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<string> SendRequest(DateDetail user)
        {
            try
            {
                await _datingContext.DateDetails.AddAsync(user);
                await _datingContext.SaveChangesAsync();
                return "Message Send";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Method used to update the existing date Request
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<DateDetail> UpdateDateDetail(DateDetail appointment)
        {
            try
            {
                _datingContext.DateDetails.Update(appointment);
                await _datingContext.SaveChangesAsync();
                return await Task.FromResult(appointment);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
