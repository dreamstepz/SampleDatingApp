﻿using System;
using System.Threading.Tasks;
using DatingApp.BusinessLayer.Interfaces;
using DatingApp.BusinessLayer.Services.Repository;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services
{
    public class DateService : IDateService
    {
        /// <summary>
        /// Creating instance/field of DateRepository and injecting into DateService Constructor
        /// </summary>
        private readonly IDateRepository _dateRepository;

        public DateService(IDateRepository dateRepository)
        {
            _dateRepository = dateRepository;
        }

        /// <summary>
        /// Method used to Create a new Date/Appointment
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<DateDetail> AddDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to Cancel the existing Date/Appointment
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<DateDetail> CancelDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get the existing Date Details by using the DatingDate
        /// </summary>
        /// <param name="DateOfRequest"></param>
        /// <returns></returns>
        public async Task<DateDetail> GetDateDetailByDate(DateTime DateOfRequest)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get the existing Date Details by using the dateId
        /// </summary>
        /// <param name="dateId"></param>
        /// <returns></returns>
        public async Task<DateDetail> GetDateDetailById(long dateId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get the existing Date Details by using the RequestSenderName
        /// </summary>
        /// <param name="RequestSenderName"></param>
        /// <returns></returns>
        public async Task<DateDetail> GetDateDetailByUser(string RequestSenderName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Update the existing Date Details
        /// </summary>
        /// <param name="RequestSenderName"></param>
        /// <returns></returns>
        public async Task<DateDetail> UpdateDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Call user repository method to send request
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<string> SendRequest(DateDetail user)
        {
            try
            {
                var result = await _dateRepository.SendRequest(user);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
