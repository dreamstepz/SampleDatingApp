﻿using System.ComponentModel.DataAnnotations;

namespace DatingApp.Entities
{
    public enum Status
    {
        Pending,
        Approved
    }
}
