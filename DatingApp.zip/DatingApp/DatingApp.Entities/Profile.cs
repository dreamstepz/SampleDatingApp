﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DatingApp.Entities
{
    public class Profile
    {
        [Key]
        public int ProfileId { get; set; }
        [Required]
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "LastName")]
        public string LastName { get; set; }
        [Required]
        [Display(Name = "Gender")]
        public string Gender { get; set; }
        [Required]
        [Display(Name = "Occupation")]
        public string Occupation { get; set; }
        [Required]
        [Display(Name = "AlternateEmail")]
        public string AlternateEmail { get; set; }
        [Required]
        [Display(Name = "MobileNumber")]
        public long MobileNumber { get; set; }
    }
}
