﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DatingApp.Entities
{
    public class DateDetail
    {
        [Key]
        public int DateId { get; set; }
        [Required]
        [Display(Name = "RequestSenderName")]
        public string RequestSenderName { get; set; }
        [Required]
        [Display(Name = "RequestReceiverName")]
        public string RequestReceiverName { get; set; }
        [Required]
        [Display(Name = "DateOfRequest")]
        public string DateOfRequest { get; set; }
        [Required]
        [Display(Name = "RequestStatus")]
        public Status RequestStatus { get; set; }
        [Required]
        [Display(Name = "RequestSenderEmail")]
        public string RequestSenderEmail { get; set; }
        [Required]
        [Display(Name = "RequestReceiverEmail")]
        public string RequestReceiverEmail { get; set; }
        [Required]
        [Display(Name = "Mobile")]
        public long Mobile { get; set; }
        [Required]
        [Display(Name = "RequestMessage")]
        public string RequestMessage { get; set; }
    }
}
